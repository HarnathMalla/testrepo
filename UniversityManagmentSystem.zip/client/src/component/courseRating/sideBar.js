// Author - Zongyu Wu
import '../../stylesheets/sideBar.css'

import * as AiIcons from 'react-icons/ai'
import * as FaIcons from 'react-icons/fa'
import * as IoIcons from 'react-icons/io5'

import { Link } from 'react-router-dom'
import React from 'react'

class SideBar extends React.Component {
    constructor(props) {
        super(props)
        this.handleNavigation = this.handleNavigation.bind(this);
        this.state = {
            currentPage: window.localStorage.getItem('pageSelected')
        }
    }
    handleNavigation = (page) => {
        window.localStorage.setItem('pageSelected', page);
        this.setState({ currentPage: page });
    }

    render() {
        return (
            <div className='navBar' >
                <nav className='nav-menu' >
                    <ul className='nav-menu-items' >
                        <li className='nav-text' onClick={() => this.handleNavigation('home')}>
                            <Link to={'/home'} state={{ page: 'home'}} className={this.state.currentPage === 'home' ? 'selected' : ''}>
                                <AiIcons.AiFillHome />
                                <span > Home </span>
                            </Link >
                        </li>
                        <li className='nav-text' onClick={() => this.handleNavigation('application')}>
                            <Link to='/application' className={this.state.currentPage === 'application' ? 'selected' : ''} >
                                <AiIcons.AiFillBook />
                                <span > Application </span>
                            </Link >
                        </li>
                        <li className='nav-text' onClick={() => this.handleNavigation('applied')}>
                            <Link to='/appliedCourses' className={this.state.currentPage === 'applied' ? 'selected' : ''}>
                                <IoIcons.IoBook />
                                <span > My Courses </span>
                            </Link >
                        </li>
                        <li className='nav-text' onClick={() => this.handleNavigation('course')}>
                            <Link to='/courseHome' className={this.state.currentPage === 'course' ? 'selected' : ''}>
                                <AiIcons.AiFillLike />
                                <span > Evaluation </span>
                            </Link >
                        </li>
                        <li className='nav-text' onClick={() => this.handleNavigation('grades')}>
                            <Link to='/grades/ViewGrades' className={this.state.currentPage === 'grades' ? 'selected' : ''}>
                                <AiIcons.AiFillStar />
                                <span > Grades </span>
                            </Link >
                        </li>
                        <li className='nav-text' onClick={() => this.handleNavigation('residence')}>
                            <Link to='/residence' className={this.state.currentPage === 'residence' ? 'selected' : ''}>
                                <FaIcons.FaHome />
                                <span > Residence </span>
                            </Link >
                        </li>
                        <li className='nav-text' onClick={() => this.handleNavigation('library')}>
                            <Link to='/Profile' className={this.state.currentPage === 'library' ? 'selected' : ''}>
                                <IoIcons.IoLibrary />
                                <span > Library </span>
                            </Link >
                        </li>

                    </ul >
                </nav>
            </div >
        )
    }
}

export default SideBar