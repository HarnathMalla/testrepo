// Author - Zongyu Wu

import CardGroup from "react-bootstrap/CardGroup";
import Card from "react-bootstrap/Card";
import { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import "../../stylesheets/courseHome.css"
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import axios from "axios";
import SideBar from "./sideBar";
import Header from "./header";
import defaultCourse from '../Images/defaultCourse.jpg';


function CourseHome() {
    const [show, setShow] = useState(false);
    const [courseId, setCourseId] = useState('');
    const [courseList, setCourseList] = useState([])

    useEffect(() => {
        axios.get("http://localhost:3000/course/all").then((response) => {
            setCourseList(response.data.course)
            console.log(response.data)
        })
    }, [])

    const handleClose = () => setShow(false);
    const handleShow = (id) => {
        setShow(true);
        setCourseId(id);
    }

    const redirectToEvaluation = (id) => window.open('/evaluation/' + id, "_self");

    return (
        <body>
            <Header />
            <SideBar />
            <div className="courseHome-content">
                <div className="courseHome-survey">
                    <h1>Course Rating</h1>
                    <CardGroup className='course-decks'>
                        {courseList.map((val, key) => {
                            console.log(val.courseImage)
                            return (
                                <Card className="course" onClick={() => {
                                    if (val.rated) {
                                        handleShow(val._id);
                                    } else {
                                        redirectToEvaluation(val._id);
                                    }
                                }}>
                                    <Card.Img variant="top" src={val.courseImage} alt="Image not loaded" />
                                    <Card.Body>
                                        <Card.Title>{val.name}</Card.Title>
                                        <Card.Text>{val.discription}</Card.Text>
                                    </Card.Body>
                                    <Card.Footer>
                                        <small className="text-muted">{val.term}</small>
                                    </Card.Footer>
                                </Card>
                            )
                        })}
                    </CardGroup>
                </div>
                <div className="reminder">
                    <Modal show={show} onHide={handleClose} style={{marginTop: '75px'}}>
                        <Modal.Header closeButton>
                            <Modal.Title>Notice</Modal.Title>
                        </Modal.Header>
                        <Modal.Body>This course has been rated! Would you like rate it again?</Modal.Body>
                        <Modal.Footer>
                            <Button variant="primary" onClick={() => {
                                redirectToEvaluation(courseId);
                            }}>
                                Yes
                            </Button>
                            <Button variant="secondary" onClick={handleClose}>
                                No
                            </Button>
                        </Modal.Footer>
                    </Modal>
                </div>
            </div>
        </body>
    )
}

export default CourseHome;