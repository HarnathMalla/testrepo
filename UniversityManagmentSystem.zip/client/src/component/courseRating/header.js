//Author - Zongyu Wu

import "../../stylesheets/header.css";

import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import NavDropdown from "react-bootstrap/NavDropdown";
import Navbar from "react-bootstrap/Navbar";
import axios from 'axios'
// import logo from "../../logo.svg";
import logo from '../Images/logomain.jpg';

function Header() {
    const [firstName, setFirstName] = useState('')
    const param = useParams();
    const userid = window.localStorage.getItem('userid');


    useEffect(() => {    
        axios.get("http://localhost:3000/userInformation/getUserDetails/" + userid).then((response) => {
            setFirstName(response.data.result.FirstName);
        })
    }, [])

    const reDirectToProfile = () => {
        console.log("redirected /pro")
        window.open('/profilehome', "_self");
    }
    const logout = () => window.open('/LoginPage', "_self");

    return (
        <div className="header">
            <Navbar>
                <Navbar.Brand>
                    <img src={logo} width="174" height="60" className="d-inline-block align-top" alt="React Bootstrap logo" />
                </Navbar.Brand>
                <Navbar.Toggle />
                <Navbar.Collapse className="justify-content-end">
                    <NavDropdown title={firstName} id="collasible-nav-dropdown">
                        <NavDropdown.Item onClick={() => reDirectToProfile()}>Profile</NavDropdown.Item>
                        <NavDropdown.Item>Account</NavDropdown.Item>
                        <NavDropdown.Item onClick={() => logout()}>Sign Out</NavDropdown.Item>
                    </NavDropdown>
                </Navbar.Collapse>
            </Navbar>
        </div>
    );
}

export default Header;