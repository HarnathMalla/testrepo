// Author -Sri Sai Bhargav Nuthakki
import React, { Component } from 'react';
import '../../stylesheets/homePage.css';
import { useRef, useState } from "react";
import "swiper/css";
import "swiper/css/navigation"
import { Swiper, SwiperSlide } from "swiper/react";
import HomeHeader from "../profileManagement/homeHeader";
import SwiperCore from 'swiper/core';
import { Navigation } from "swiper/modules";
import slide1 from '../Images/slide1.jpg';
import slide2 from '../Images/slide2.jpg';
import slide3 from '../Images/slide3.jpg';
import camp1 from '../Images/campus1.jpg';
import camp2 from '../Images/campus2.jpg';
import camp3 from '../Images/campus3.jpg';

SwiperCore.use([Navigation]);


class HomePage extends Component {
    state = {}
    render() {
        return (
            <div class="homePage">

                <HomeHeader />

                <div className='swiper-div'>
                    <Swiper navigation={true} className="mySwiper">
                        <SwiperSlide className='rslide'>
                            <img className="swiper-image" src={slide1} />
                        </SwiperSlide>
                        {/* <SwiperSlide>
                            <img className="swiper-image" src="https://s3.amazonaws.com/libapps/accounts/21306/images/sws_stairs.jpg" />
                        </SwiperSlide> */}
                        <SwiperSlide>
                            <img className="swiper-image" src={slide2} />
                        </SwiperSlide>
                        <SwiperSlide>
                            <img className="swiper-image" src={slide3} />
                        </SwiperSlide>
                    </Swiper>
                </div>

                <div class="campuses">
                    <div class="campus">
                        <div>
                            <h2>Greenwich campus</h2>
                            <p>Greenwich Campus sits on a World Heritage Site and is located in the heart of Greenwich, south-east London. The neighbourhood has a lively atmosphere but is away from the hustle and bustle of the city, making it the ideal place to study.
                                The campus is surrounded by historical landmarks, as well as Greenwich Park and a selection of bars and restaurants. Many sites around the campus have been used as sets for films, such as The King's Speech, Les Misérables, Four Weddings and a Funeral, and The Queen.</p>
                        </div>
                        <img src={camp1} />
                    </div>
                    <div class="campus" style={{ flexDirection: 'row-reverse' }}>
                        <div>
                            <h2>Avery hill campus</h2>
                            <p>Surrounded by green spaces, Avery Hill Campus is located in Eltham, south-east London. It has first-rate teaching and sporting facilities, as well as student accommodation.
Avery Hill is the ideal setting for students looking to study in London. Not only does it have a campus university vibe with teaching and living space, it is also just 30 minutes by train from central London.</p>
                        </div>
                        <img src={camp2} />
                    </div>
                    <div class="campus">
                        <div>
                            <h2>Medway campus</h2>
                            <p>Where you choose to study is a really important decision, and we are delighted to welcome you to our historic Medway Campus in Chatham, Kent.
                                Medway Campus has a rich naval history. Its red-brick buildings were previously a Royal Navy base. Nelson's flagship HMS Victory was built at Chatham's Historic Dockyard.
                                The campus also has amazing cafés and bars, including those in Pembroke and Pilkington Buildings. An attractive piazza-style area with outdoor seating is ideal for events. There are also plenty of green spaces, with a tennis court.</p>
                        </div>
                        <img src={camp3} />
                    </div>
                </div>

            </div>


        );
    }
}

export default HomePage;