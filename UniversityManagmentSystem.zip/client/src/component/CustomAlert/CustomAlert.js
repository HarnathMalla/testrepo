import React from 'react';
import Alert from 'react-bootstrap/Alert';
import PropTypes from 'prop-types';

class CustomAlert extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      alertType: '',
      alertShow: false,
      alertText: ''
    }
  }

  componentDidMount() {
    document.addEventListener('alertCreated', this.showAlert, false);
    console.log("hi",window.localStorage.getItem('alertInfo'), typeof(window.localStorage.getItem('alertInfo')));
    const alertInfo = JSON.parse(window.localStorage.getItem('alertInfo'));
    console.log("alert info -> ", alertInfo, alertInfo.alertShow);
    if (alertInfo && alertInfo.alertShow === true) {
      console.log("alert show yes -> ");
      this.showAlert({
        detail: {
          alertText: alertInfo.alertText,
          alertType: alertInfo.alertType,
          alertShow: alertInfo.alertShow
        }
      });
    }
  }

  componentWillUnmount() {
    document.removeEventListener('alertCreated', this.showAlert);
  }

  showAlert = (e) => {
    const alertInfo = {
      alertText: e.detail.alertText,
      alertType: e.detail.alertType,
      alertShow: true
    };
    window.localStorage.setItem('alertInfo', JSON.stringify(alertInfo));
    this.setState({
      alertText: e.detail.alertText,
      alertType: e.detail.alertType,
      alertShow: true
    });
    setTimeout(() => {
      this.setState({
        alertShow: false
      });
      window.localStorage.setItem('alertInfo', JSON.stringify({
        alertText: '',
        alertType: '',
        alertShow: false
      }))
    }, 3000);
  }

  render() {
    return (
      <Alert className='myalert' key={this.state.alertType} variant={this.state.alertType} show={this.state.alertShow} onClose={() => this.setState({ alertShow: false })} dismissible>
        {this.state.alertText}
      </Alert>
    )
  }
}

export default CustomAlert;