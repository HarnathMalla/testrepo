/*Author - Sowmya Busanagari*/
import "../../stylesheets/application.css";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { useState } from 'react';
import { useNavigate, useParams } from "react-router-dom";
import SideBar from "../courseRating/sideBar";
import Header from "../courseRating/header";
import Axios from 'axios';
import UserDetails from "../profileManagement/UserDetails";

function Application() {
    const [studentEmail, setStudentEmail] = useState('');
    const [courseId, setCourseId] = useState('');
    const [userEmail, setUserEmail] = useState('');
    const [paramEmail, setParamEmail] = useState('');
    const [paramName, setParamName] = useState('');
    const [applied, setApplied] = useState('');
    const param = useParams();

    const redirectToCourseHome = () => window.open('/application', "_self");
    Axios.get("http://localhost:3000/courseApplication/existedCourse", {
        params: {
            courseId: param.id,
            studentEmail: paramEmail
        },
    }).then((response) => {
        setApplied(response.data.applied)
        console.log(applied)

    })

    const userid = window.localStorage.getItem('userid');

    Axios.get("http://localhost:3000/userInformation/getUserDetails/" + userid).then((response) => {
        console.log(response.data.result.FirstName)
        setParamEmail(response.data.result.Email);
        setParamName(response.data.result.FirstName);
    })



    const handleSubmit = () => {

        if (applied == true) {
            // alert("Already applied!!")
            const event = new CustomEvent('alertCreated', {
                detail: {
                    alertText: "Already applied!!",
                    alertType: 'info',
                    alertShow: true
                },
                cancelable: true,
                bubbles: true
            });
            window.parent.document.dispatchEvent(event);
            redirectToCourseHome();
        }
        else {
            Axios.post('http://localhost:3000/courseApplication/apply/' + param.id, {
                studentEmail: paramEmail
            });
            Axios.post('http://localhost:3000/grade/add/' + param.id, {
                studentName: paramName,
                studentEmail: paramEmail
            });
            // alert("Thank you for the Applying.");
            const event = new CustomEvent('alertCreated', {
                detail: {
                    alertText: "Thank you for the Applying.",
                    alertType: 'success',
                    alertShow: true
                },
                cancelable: true,
                bubbles: true
            });
            window.parent.document.dispatchEvent(event);
            redirectToCourseHome();
        }
    }

    const handleCancel = () => {
        alert("Canceled. You can continue next time.");
        redirectToCourseHome();
    }

    return (
        <body>
            <Header />
            <SideBar />
            <div className="side">
                <h1>Course Application</h1>
                <div className="survey-application">

                    <Form>

                        <Form.Group className="formBasicInput">
                            <Form.Label>Email address</Form.Label><br></br>
                            <Form.Label>{paramEmail}</Form.Label>
                        </Form.Group>
                        <Button className="cancelButton" onClick={handleCancel}>
                            Cancel
                        </Button>
                        <Button className="applyButton" onClick={handleSubmit}>
                            Confirm
                        </Button>
                    </Form>
                </div>
            </div>
        </body>
    )
}

export default Application;