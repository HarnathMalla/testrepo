import 'bootstrap/dist/css/bootstrap.min.css'
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Application from './component/courseApplication/application';
import AppliedCourses from './component/courseApplication/appliedCourses';
import CourseApplication from "./component/courseApplication/courseApplicationHome";
import CourseHome from "./component/courseRating/courseHome";
import CourseSelection from './component/Grades/CourseSelection';
import Evaluation from './component/courseRating/evaluation';
import ForgetPassword from './component/profileManagement/forgetPassword';
import Grade from './component/Grades/Grade';
import LoginPage from './component/profileManagement/LoginPage';
import MarkingPage from './component/Grades/MarkingPage';
import ProfileInfo from './component/profileManagement/ProfileInfo';
import RegistrationPage from './component/profileManagement/registrationPage';
import ResetPasswordPage from './component/profileManagement/resetPasswordPage';
import Residence from './component/residencePage/residence';
import Login from './component/LibraryManagement/Login';
import Profile from './component/LibraryManagement/Profile';
import SideBar from './component/courseRating/sideBar';
import UpdateProfile from './component/profileManagement/updateProfile';
import ViewGrade from './component/Grades/viewGrades';
import HomePage from './component/Home/homePage';
import Contact from './component/Home/Contact';
import ViewFeedback from './component/Grades/viewFeedback';
import LexChat from "react-lex";
import SearchBar from './component/LibraryManagement/searchBar';
import Details from './component/LibraryManagement/Details';
import CustomAlert from './component/CustomAlert/CustomAlert';
import './App.css';


function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Routes>
          <Route exact path="/" element={<HomePage/>}></Route>
          <Route exact path="/sideBar" element={<SideBar/>}></Route>
          <Route exact path="/courseHome" element={<CourseHome/>}></Route>
          <Route exact path="/evaluation/:id" element={<Evaluation/>}></Route>
          <Route exact path="/application" element={<CourseApplication/>}></Route>
          <Route exact path="/apply/:id" element={<Application/>}></Route>
          <Route exact path="/appliedCourses" element={<AppliedCourses/>}></Route>
          <Route exact path="/grades/GradeHome/:id" element={<Grade/>}></Route>
          <Route exact path="/grades/courseSelection" element={<CourseSelection/>}></Route>
          <Route exact path="/grades/markingPage/:id" element={<MarkingPage/>}></Route>
          <Route exact path="/RegistrationPage" element={<RegistrationPage/>}></Route>
          <Route exact path="/LoginPage" element={<LoginPage/>}></Route>
          <Route exact path="/ForgetPassword" element={<ForgetPassword/>}></Route>
          <Route exact path="/ResetPasswordPage" element={<ResetPasswordPage/>}></Route>
          <Route exact path="/UpdateProfilePage" element={<UpdateProfile/>}></Route>
          <Route exact path="/HomePage/:ID" element={<CourseHome/>}></Route>
          <Route exact path="/grades/viewGrades" element={<ViewGrade/>}></Route>
          <Route exact path="/profilehome" element={<ProfileInfo/>}></Route>
          <Route exact path="/residence" element={<Residence/>}></Route>

          <Route exact path="/Login" element={<Login/>}></Route>

          <Route exact path="/Profile" element={<Profile/>}></Route>
          <Route exact path='/home' element={<HomePage/>}></Route>
          <Route exact path='/contact' element={<Contact/>}></Route>
          <Route exact path="/viewFeedback" element={<ViewFeedback/>}></Route>
          <Route exact path="/libraryProfile" element={<profile/>}></Route>
          <Route exact path="/searchBar" element={<SearchBar/>}></Route>
          <Route exact path="/details" element={<Details/>}></Route>
        </Routes>
      </div>
      {/* <div>
          <LexChat
            botName="Navigation"
            IdentityPoolId="us-east-1:490d8d9b-4877-4f91-a06d-aee20121e312"
            placeholder="Placeholder text"
            style={{ position: 'absolute' }}
            backgroundColor="#FFFFFF"
            height="430px"
            region="us-east-1"
            headerText="Chat with our " />
        </div> */}
        <CustomAlert/>

    </BrowserRouter>
  );
}

export default App;